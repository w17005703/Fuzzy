
public class Fuzzy_Th {
	public float downslope(float x, float left, float right)
	{
		return ((right-x)/(right-left));
	}
	public float upslope(float x, float left, float right)
	{
		return ((x-left)/(right-left));
	}
	
	public float close(float x)
	{
		float left = 10;
		float right = 30;
		if (x<=left) return 1;
		else if (x>=right) return 0;
		else return downslope(x, left, right);
	}
	
	public float medium(float x)
	{
		float left_b = 10;
		float left_t = 30;
		float right_t = 50;
		float right_b = 70;
		
		if (x<=left_b) return 0;
		
		else if ((x>left_b) && (x<left_t))
			return upslope(x, left_b, left_t);
		
		else if ((x>right_t) && (x<right_b))
			return downslope(x, right_t, right_b);
		
		else if (x>=right_b) return 0;
		
		else return 1;
	}
	
	public float far(float x)
	{
		float left = 50;
		float right = 70;
		if (x<=left) return 0;
		else if (x>=right) return 1;
		else return upslope (x, left, right);
	}
	
	public float tiny(float x)
	{
		float left = 3;
		float right = 10;
		if (x<=left) return 1;
		else if (x>=right) return 0;
		else return downslope(x, left, right);
	}
	
	public float small(float x)
	{
		float left_b = 3;
		float left_t = 10;
		float right_t = 15;
		float right_b = 20;
		
		if (x<=left_b) return 0;
		
		else if ((x>left_b) && (x<left_t))
			return upslope(x, left_b, left_t);
		
		else if ((x>right_t) && (x<right_b))
			return downslope(x, right_t, right_b);
		
		else if (x>=right_b) return 0;
		
		else return 1;
	}
	
	public float moderate(float x)
	{
		float left_b = 15;
		float left_t = 20;
		float right_t = 25;
		float right_b = 30;
		
		if (x<=left_b) return 0;
		
		else if ((x>left_b) && (x<left_t))
			return upslope(x, left_b, left_t);
		
		else if ((x>right_t) && (x<right_b))
			return downslope(x, right_t, right_b);
		
		else if (x>=right_b) return 0;
		
		else return 1;
	}
	
	public float large(float x)
	{
		float left = 25;
		float right = 30;
		if (x<=left) return 0;
		else if (x>=right) return 1;
		else return upslope (x, left, right);
	}
	
}
