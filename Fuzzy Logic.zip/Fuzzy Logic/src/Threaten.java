
public class Threaten {
	public static void main(String[] args) {
		Fuzzy_Th f1 = new Fuzzy_Th();
		
		float x = 45;
	}
}
